<?php

namespace App\Http\Controllers;

use App\Models\Guru;
use App\Models\Kelas;
use App\Models\status_rfid;
use App\Models\User;
use Illuminate\Http\Request;
use DataTables;

class AdminController extends Controller
{
    public function index(){
        return view('page.administrator');
    }

    public function guru(){
        return view('page.guru');
    }

    public function gurujson(){
        $dataguru = Guru::all();
        return DataTables::of($dataguru)->make(true);
    }

    public function kelasjson(){
        $dataguru = Kelas::all();
        return DataTables::of($dataguru)->make(true);
    }

    public function rfid($id){
        $cek = status_rfid::find(1);
        if($cek->scan == 'T'){
           $user = new User(); 
           $user->name = $id;
           $user->email = $id;
           $user->password = $id;
           $user->roles_id = 2;
           $user->save();

           $data = User::latest()->first();
           $guru = new Guru();
           $guru->nik = $id;
           $guru->nama = '';
           $guru->jenis_kelamin = 'Laki-laki';
           $guru->alamat = '';
           $guru->users_id = $data->id;
           $guru->save();
        }else{
            $ada = Guru::where('nik', $id)->first();
            if($ada){
                echo "buka";
            }else{
                echo "tutup";
            }
        }
    }

    public function simpan(Request $req){
        $req->validate([
            'nama' => ['required'],
            'nik' => ['required'],
            'jk' => ['required'],
            'alamat' => ['required'],
        ]);

        $update = Guru::where('nik', $req->nik)->update([
            'nama' => $req->nama,
            'jenis_kelamin' => $req->jk,
            'alamat' => $req->alamat,
        ]);

        if($update){
            return redirect('guru')->with('success', 'Sukses update');
        }else{
            return back()->with('error', 'Gagal melakukan update');
        }
    }
}
